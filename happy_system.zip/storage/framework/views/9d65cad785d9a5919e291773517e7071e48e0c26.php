
    <div class="sidebar" data-color="blue">
        <!--
        Tip 1: You can change the color of the fdebar using: data-color="blue | green | orange | red | yellow"
        -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
          TH
        </a>
        <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
          Toko Happy
        </a>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <!--
          <li class="active ">
            <a href="<?php echo e(route('admin.dashboard.index')); ?>">
              <i class="now-ui-icons design_app"></i>
              <p>Dashboard</p>
            </a>
          </li>
          
          <li>
            <a href="<?php echo e(route('admin.admin.index')); ?>">
              <i class="now-ui-icons sport_user-run"></i>
              <p>Akun Admin</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.cashier.index')); ?>">
              <i class="now-ui-icons users_single-02"></i>
              <p>Akun Kasir</p>
            </a>
          </li>
-->
          <li>
            <a href="<?php echo e(route('admin.category.index')); ?>">
              <i class="now-ui-icons design_app"></i>
              <p>Kategori Produk</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.product.index')); ?>">
              <i class="now-ui-icons design_palette"></i>
              <p>Produk</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.supply.index')); ?>">
              <i class="now-ui-icons health_ambulance"></i>
              <p>Kelola Pasok</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.retur.index')); ?>">
              <i class="now-ui-icons health_ambulance"></i>
              <p>Kelola Retur</p>
            </a>
          </li>
          <!--
          <li>
            <a href="<?php echo e(route('admin.transaction.index')); ?>">
              <i class="now-ui-icons shopping_cart-simple"></i>
              <p>Transaksi</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.report.index')); ?>">
              <i class="now-ui-icons education_paper"></i>
              <p>Laporan</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.setting.index')); ?>">
              <i class="now-ui-icons ui-1_settings-gear-63"></i>
              <p>Pengaturan</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('admin.profile.index')); ?>">
              <i class="now-ui-icons business_badge"></i>
              <p>Akun Saya</p>
            </a>
          </li>
        </ul>
-->
      </div>
    </div><?php /**PATH C:\xampp\htdocs\happy_system\resources\views/component/_sidebar_admin.blade.php ENDPATH**/ ?>