<style>
  td{
    padding-right: 50px;
  }

</style>
<p><?php echo e(App\Models\Company::take(1)->first()->name); ?></p>
<p><?php echo e(App\Models\Company::take(1)->first()->address); ?></p>
<p>Kasir : <?php echo e($transaction->user->name); ?></p>
<p>Tanggal : <?php echo e(date('m-d-Y', strtotime($transaction->created_at))); ?></p>
==========================================

<table>
  <?php $__currentLoopData = $productTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($product->product->name); ?></td>
    <td><?php echo e($product->quantity); ?></td>
    <td><?php echo e($product->product->price); ?></td>
    <td><?php echo e($product->product->price * $product->quantity); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td colspan="3" align="right">Total Pembelian</td>
    <td><?php echo e($transaction->purchase_order); ?></td>
  </tr>
  <tr>
    <td colspan="3" align="right">Bayar</td>
    <td><?php echo e($transaction->pay); ?></td>
  </tr>
  <tr>
    <td colspan="3" align="right">Kembalian</td>
    <td><?php echo e($transaction->return); ?></td>
  </tr>
</table>
==========================================<br><br>
Terimakasih telah berbelanja. Semoga harimu menyenangkan<?php /**PATH C:\xampp\htdocs\happy_system\resources\views/admin/report/print.blade.php ENDPATH**/ ?>