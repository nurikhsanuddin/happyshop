<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Detail Pasok</h4><hr>
          <div class="card-title">
            <table>
                <tr>
                    <td>Nama Pemasok</td>
                    <td>:</td>
                    <td> &nbsp; <?php echo e($supply->user->name); ?></td>
                </tr>
                <tr>
                    <td>Total Produk</td>
                    <td>:</td>
                    <td> &nbsp; <?php echo e($supply->productSupply()->count()); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Pasok</td>
                    <td>:</td>
                    <td> &nbsp; <?php echo e($supply->supply_date); ?></td>
                </tr>
                </table>
            </div>
        </div>
        <hr>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable">
              <thead>
                <th>
                  No
                </th>
                <th>
                  Nama Produk
                </th>
                <th>
                  Jumlah
                </th>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $product_supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <th><?php echo e($key+1); ?></th>
                      <th><?php echo e($product->product->name); ?></th>
                      <th><?php echo e($product->quantity); ?></th>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\happy_system\resources\views/admin/supply/show.blade.php ENDPATH**/ ?>