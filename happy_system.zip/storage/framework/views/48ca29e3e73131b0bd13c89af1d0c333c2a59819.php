<style>
  td{
    padding-right: 50px;
  }

</style>
<p>Laporan Stok Barang</p>
<p><?php echo e(App\Models\Company::take(1)->first()->name); ?></p>
<p><?php echo e(App\Models\Company::take(1)->first()->address); ?></p>

<p>Tanggal : <?php echo e(date('m-d-Y',)); ?></p>
<table border="1">
<tr>
    <td>Nama</td>
    <td>Merk</td>
    <td>Stok</td>
    <td>Cost</td>
    <td>Total Cost</td>
  </tr>
  <br>
  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($product->name); ?></td>
    <td><?php echo e($product->merk); ?></td>
    <td><?php echo e($product->quantity); ?></td>
    <td><?php echo e(format_uang($product->price)); ?></td>
    <td><?php echo e(format_uang($product->price*$product->quantity)); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td colspan="3" align="right">Total Modal</td>
    <td><?php echo e(format_uang($product->totalCost)); ?></td>
  </tr>
</table>
footer<?php /**PATH /var/www/html/happy_system/resources/views/admin/product/printproduct.blade.php ENDPATH**/ ?>